// Кubning qirrasining uzunligi berilgan.
// Кubning hajmini va yon sirtining yuzini 
// hisoblash algoritmini tuzing.

let a=prompt(`a ni kiritng:`);
let V=a**3;
let S=6*(a**2);
console.log(`HAJM=${V}`);
console.log(`YUZA=${S}`);